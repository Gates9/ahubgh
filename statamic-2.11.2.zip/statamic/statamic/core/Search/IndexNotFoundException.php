<?php

namespace Statamic\Search;

class IndexNotFoundException extends \Exception
{

}
