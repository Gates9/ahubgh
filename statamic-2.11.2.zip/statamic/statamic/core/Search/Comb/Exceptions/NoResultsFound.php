<?php

namespace Statamic\Search\Comb\Exceptions;

/**
* Thrown when no results are found
*/
class NoResultsFound extends Exception
{

}
