<?php

namespace Statamic\Stache;

class EmptyStacheException extends \RuntimeException
{
}