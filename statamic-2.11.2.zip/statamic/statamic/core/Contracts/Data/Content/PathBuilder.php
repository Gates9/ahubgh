<?php

namespace Statamic\Contracts\Data\Content;

interface PathBuilder {

}


