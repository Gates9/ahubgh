<?php

namespace Statamic\Exceptions;

class SilentFormFailureException extends \Exception
{
    //
}
