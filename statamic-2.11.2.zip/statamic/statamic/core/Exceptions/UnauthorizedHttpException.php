<?php

namespace Statamic\Exceptions;

use Symfony\Component\HttpKernel\Exception\HttpException;

class UnauthorizedHttpException extends HttpException
{

}
