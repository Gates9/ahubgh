<?php

namespace Statamic\Imaging;

class AssetNotFoundException extends \Exception
{

}
