---
title: Gallery
images:
  - /assets/img/black-bear-cubs.jpg
  - /assets/img/redwood-balance.jpg
  - /assets/img/redwood-james-irvine-trail.jpg
  - /assets/img/redwood-sign.jpg
  - /assets/img/redwood-snow.jpg
  - /assets/img/redwood-sunrise.jpg
  - /assets/img/stetson.jpg
  - /assets/img/dangle.jpg
  - /assets/img/desert.jpg
  - /assets/img/redwood-north-ridge-trail.jpg
template: gallery
fieldset: gallery
id: 3cd2d431-699c-417c-8d57-9183cd17a6fc
---
I like to snap a few photos from time to time. These are those photos.
