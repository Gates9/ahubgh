---
title: About Me
template: about
fieldset: about
id: 72c016c6-cc0a-4928-b53b-3275f3f6da0a
fun_facts:
  - "I grew up in West Virginia but moved to California in the mid 90s"
  - "My life is about as organized as the $5 DVD bin at Wal-Mart"
  - "My first computer was a Commodore 64"
  - "I'm a paper cut survivor"
  - "I have a restraining order against me from J.K. Rowling but I promise it's just a misunderstanding"
  - "I hope one day I love something the way women in commercials love yogurt"
  - "I’m not smart. I just wear glasses."
---
My name is Niles Peppertrout. I am a relatively new Park Ranger working at Redwood Nation Park with a background in Applied Harry Potter Sciences from [Frostburg University](http://frostburg.edu). I've always loved the outdoors but never dreamed I'd get paid to wander them. [Join me on my adventure](/blog)!

![Me](/assets/img/me.jpg)
