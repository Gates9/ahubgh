title: Survival Knife
id: 293e6af3-ae18-4e53-bd95-9a4a94be3003
amazon_id: B003R0LSMO
photo: http://ecx.images-amazon.com/images/I/81WI%2BLf8cSL.jpg
