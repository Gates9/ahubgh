title: Schnitzel with Noodles
amazon_id: B00A9BDJJO
photo: http://ecx.images-amazon.com/images/I/41%2BBsjfO8%2BL.jpg
id: 55a64c19-69db-4ff2-9da9-2f13da340007
